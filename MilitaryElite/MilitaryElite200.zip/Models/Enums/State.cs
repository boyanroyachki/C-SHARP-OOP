﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Models.Enums
{
    public enum State
    {
        InProgress = 0,
        Finished = 1,
    }
}
